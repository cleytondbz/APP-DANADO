import { useApp } from '@/contexts/AppContext';
import { TrendingUp, ShoppingCart, Lock, CreditCard, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ServerConfig } from '@/components/ServerConfig';

export default function SelectionScreen() {
  const { setScreen, saldoDia, setSaldoDia } = useApp();
  const [showSenhaVendas, setShowSenhaVendas] = useState(false);
  const [senhaVendasInput, setSenhaVendasInput] = useState('');
  const [showAlterarSenha, setShowAlterarSenha] = useState(false);
  const [senhaAntiga, setSenhaAntiga] = useState('');
  const [senhaNova, setSenhaNova] = useState('');
  const [confirmarSenhaNova, setConfirmarSenhaNova] = useState('');
  const [senhaVendasAtual, setSenhaVendasAtual] = useState(localStorage.getItem('senhaVendas') || '2512');
  const [showServerConfig, setShowServerConfig] = useState(false);

  const abrirVendas = () => {
    setShowSenhaVendas(true);
    setSenhaVendasInput('');
  };

  const confirmarSenhaVendas = () => {
    // Permitir acesso com a senha matriz ou a senha atual
    if (senhaVendasInput !== senhaVendasAtual && senhaVendasInput !== '32636995') {
      toast.error('Senha incorreta!');
      setSenhaVendasInput('');
      return;
    }
    setShowSenhaVendas(false);
    setSenhaVendasInput('');
    setScreen('storeSelection');
  };

  const alterarSenha = () => {
    if (senhaAntiga !== senhaVendasAtual) {
      toast.error('Senha antiga incorreta!');
      setSenhaAntiga('');
      return;
    }
    if (senhaNova !== confirmarSenhaNova) {
      toast.error('As senhas novas não conferem!');
      setSenhaNova('');
      setConfirmarSenhaNova('');
      return;
    }
    if (senhaNova.length < 4) {
      toast.error('A senha deve ter pelo menos 4 dígitos!');
      return;
    }
    localStorage.setItem('senhaVendas', senhaNova);
    setSenhaVendasAtual(senhaNova);
    toast.success('Senha alterada com sucesso!');
    setShowAlterarSenha(false);
    setSenhaAntiga('');
    setSenhaNova('');
    setConfirmarSenhaNova('');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
        <h1 className="text-2xl font-bold text-foreground">app <span className="text-accent">Danado</span></h1>
        <p className="text-muted-foreground text-sm mt-2">Selecione a área desejada</p>
      </motion.div>

      <div className="flex flex-col gap-4 w-full max-w-sm">
        <div className="flex gap-4">
          <motion.button initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}
            onClick={abrirVendas}
            className="flex-1 bg-primary rounded-2xl p-6 flex flex-col items-center gap-3 hover:opacity-90 active:scale-95 transition-all card-glow"
          >
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
              <TrendingUp className="w-7 h-7 text-primary-foreground" />
            </div>
            <span className="text-primary-foreground font-bold text-lg">VENDAS</span>
            <span className="text-primary-foreground/70 text-xs">Gerenciar vendas</span>
          </motion.button>

          <motion.button initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}
            onClick={() => toast.info('Área de compras em desenvolvimento!')}
            className="flex-1 bg-muted rounded-2xl p-6 flex flex-col items-center gap-3 relative overflow-hidden opacity-60"
          >
            <div className="absolute top-2 right-2 bg-warning/20 text-warning text-[10px] font-bold px-2 py-0.5 rounded-full">EM BREVE</div>
            <div className="w-14 h-14 rounded-full bg-muted-foreground/10 flex items-center justify-center">
              <ShoppingCart className="w-7 h-7 text-muted-foreground" />
            </div>
            <span className="text-muted-foreground font-bold text-lg">COMPRAS</span>
            <span className="text-muted-foreground/50 text-xs">Em breve...</span>
            <Lock className="w-4 h-4 text-muted-foreground/40 absolute bottom-3 right-3" />
          </motion.button>
        </div>

        <motion.button initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          onClick={() => setScreen('caixaSelection')}
          className="w-full bg-accent rounded-2xl p-6 flex flex-col items-center gap-3 hover:opacity-90 active:scale-95 transition-all card-glow"
        >
          <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
            <CreditCard className="w-7 h-7 text-accent-foreground" />
          </div>
          <span className="text-accent-foreground font-bold text-lg">CAIXA</span>
          <span className="text-accent-foreground/70 text-xs">Fechamento de caixa</span>
        </motion.button>
      </div>

      {/* Botão de Configuração */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        onClick={() => setShowServerConfig(!showServerConfig)}
        className="w-full max-w-sm mt-6 flex items-center justify-center gap-2 px-4 py-2 bg-muted rounded-lg hover:bg-muted/80 transition-colors"
      >
        <Settings className="w-4 h-4" />
        <span className="text-sm font-medium">Configurações do Servidor</span>
      </motion.button>

      {/* Modal de Configuração do Servidor */}
      {showServerConfig && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
        >
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-foreground">Configurações</h2>
              <button
                onClick={() => setShowServerConfig(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                ✕
              </button>
            </div>
            <ServerConfig />
          </div>
        </motion.div>
      )}

      {/* Campo Saldo do Dia */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="w-full max-w-sm mt-8 bg-card rounded-2xl p-6 card-glow"
      >
        <label className="text-xs font-semibold text-muted-foreground uppercase mb-3 block">
          Saldo do Dia
        </label>
        <div className="flex gap-2">
          <Input
            type="number"
            value={saldoDia}
            onChange={(e) => setSaldoDia(parseFloat(e.target.value) || 0)}
            placeholder="0,00"
            className="flex-1 text-lg font-bold"
            step="0.01"
          />
          <div className="flex items-center justify-center px-4 bg-primary/10 rounded-lg">
            <span className="text-lg font-bold text-primary">
              R$ {saldoDia.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>
      </motion.div>

      {/* Modal de Alterar Senha */}
      {showAlterarSenha && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-background rounded-lg shadow-lg p-6 w-96 max-w-[90vw]"
          >
            <h2 className="text-lg font-bold text-foreground mb-4">Alterar Senha de Vendas</h2>
            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase mb-2 block">
                Senha Antiga
              </label>
              <Input
                type="tel"
                value={senhaAntiga}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, '');
                  setSenhaAntiga(value);
                }}
                placeholder="Digite a senha antiga"
                className="w-full tracking-widest"
                maxLength={4}
                autoFocus
              />
            </div>
            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase mb-2 block">
                Senha Nova
              </label>
              <Input
                type="tel"
                value={senhaNova}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, '');
                  setSenhaNova(value);
                }}
                placeholder="Digite a senha nova"
                className="w-full tracking-widest"
                maxLength={4}
              />
            </div>
            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase mb-2 block">
                Confirmar Senha Nova
              </label>
              <Input
                type="tel"
                value={confirmarSenhaNova}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, '');
                  setConfirmarSenhaNova(value);
                }}
                placeholder="Confirme a senha nova"
                className="w-full tracking-widest"
                maxLength={4}
              />
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => {
                  setShowAlterarSenha(false);
                  setSenhaAntiga('');
                  setSenhaNova('');
                  setConfirmarSenhaNova('');
                }}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={alterarSenha}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                Alterar
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Modal de Senha para VENDAS */}
      {showSenhaVendas && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-background rounded-lg shadow-lg p-6 w-96 max-w-[90vw]"
          >
            <h2 className="text-lg font-bold text-foreground mb-4">Acesso à Área de Vendas</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Digite a senha para acessar a área de vendas.
            </p>
            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase mb-2 block">
                Senha
              </label>
              <Input
                type="password"
                inputMode="numeric"
                value={senhaVendasInput}
                onChange={(e) => {
                  const value = e.target.value.replace(/[^0-9]/g, '');
                  setSenhaVendasInput(value);
                }}
                placeholder="Digite a senha"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    confirmarSenhaVendas();
                  }
                }}
                className="w-full tracking-widest"
                autoFocus
                maxLength={15}
              />
            </div>
            <div className="flex gap-3">
            <Button
              onClick={() => {
                setShowSenhaVendas(false);
                setSenhaVendasInput('');
              }}
              variant="outline"
              className="flex-1"
            >
              Cancelar
            </Button>
              <Button
                onClick={confirmarSenhaVendas}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                Confirmar
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
