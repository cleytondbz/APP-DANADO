import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Arquivo de persistência de dados
const DATA_FILE = path.join(__dirname, 'data.json');

// Função para carregar dados do arquivo
function loadDataFromFile() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('[Server] Erro ao carregar dados:', error);
  }
  return null;
}

// Função para salvar dados no arquivo
function saveDataToFile(data: Record<string, any>) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('[Server] Erro ao salvar dados:', error);
  }
}

// Middleware
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Dados em memória (para teste local)
// Em produção, isso seria um banco de dados
let dataStore: Record<string, any> = {
  stores: {},
  categories: [],
  entries: [],
  debts: [],
  settings: {},
  saldoDia: 0,
  caixa: {},
  fechamento: {},
  lancamentos: {},
};

// Carregar dados do arquivo na inicialização
const loadedData = loadDataFromFile();
if (loadedData) {
  dataStore = loadedData;
  console.log('[Server] Dados carregados do arquivo');
}
// ==================== APIs REST ====================

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ==================== STORES ====================
app.get('/api/stores', (_req: Request, res: Response) => {
  res.json(dataStore.stores);
});

app.post('/api/stores', (req: Request, res: Response) => {
  const { id, storeName, cnpj } = req.body;
  const store = { id, storeName, cnpj, createdAt: new Date().toISOString() };
  dataStore.stores.push(store);
  res.json(store);
});

// ==================== CATEGORIES ====================
app.get('/api/categories/:storeId', (req: Request, res: Response) => {
  const { storeId } = req.params;
  const categories = dataStore.categories.filter((c: any) => c.storeId === storeId);
  res.json(categories);
});

app.post('/api/categories', (req: Request, res: Response) => {
  const { id, storeId, name, operation, order } = req.body;
  const category = { id, storeId, name, operation, order, createdAt: new Date().toISOString() };
  dataStore.categories.push(category);
  res.json(category);
});

app.put('/api/categories/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { name, operation, order } = req.body;
  const index = dataStore.categories.findIndex((c: any) => c.id === id);
  if (index !== -1) {
    dataStore.categories[index] = { ...dataStore.categories[index], name, operation, order, updatedAt: new Date().toISOString() };
    res.json(dataStore.categories[index]);
  } else {
    res.status(404).json({ error: 'Category not found' });
  }
});

app.delete('/api/categories/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  dataStore.categories = dataStore.categories.filter((c: any) => c.id !== id);
  res.json({ success: true });
});

// ==================== ENTRIES ====================
app.get('/api/entries/:storeId/:year/:month', (req: Request, res: Response) => {
  const { storeId, year, month } = req.params;
  const monthStr = String(month).padStart(2, '0');
  const datePrefix = `${year}-${monthStr}`;
  const entries = dataStore.entries.filter((e: any) => 
    e.storeId === storeId && e.date.startsWith(datePrefix)
  );
  res.json(entries);
});

app.post('/api/entries', (req: Request, res: Response) => {
  const { id, storeId, date, values } = req.body;
  const entry = { id, storeId, date, values, createdAt: new Date().toISOString() };
  dataStore.entries.push(entry);
  res.json(entry);
});

app.put('/api/entries/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { values } = req.body;
  const index = dataStore.entries.findIndex((e: any) => e.id === id);
  if (index !== -1) {
    dataStore.entries[index] = { ...dataStore.entries[index], values, updatedAt: new Date().toISOString() };
    res.json(dataStore.entries[index]);
  } else {
    res.status(404).json({ error: 'Entry not found' });
  }
});

// ==================== DEBTS ====================
app.get('/api/debts', (_req: Request, res: Response) => {
  res.json(dataStore.debts);
});

app.post('/api/debts', (req: Request, res: Response) => {
  const { id, personName, description, amount, date } = req.body;
  const debt = { id, personName, description, amount, date, paid: false, createdAt: new Date().toISOString() };
  dataStore.debts.push(debt);
  res.json(debt);
});

app.put('/api/debts/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { paid, paidDate, paidAmount } = req.body;
  const index = dataStore.debts.findIndex((d: any) => d.id === id);
  if (index !== -1) {
    dataStore.debts[index] = { ...dataStore.debts[index], paid, paidDate, paidAmount, updatedAt: new Date().toISOString() };
    res.json(dataStore.debts[index]);
  } else {
    res.status(404).json({ error: 'Debt not found' });
  }
});

app.delete('/api/debts/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  dataStore.debts = dataStore.debts.filter((d: any) => d.id !== id);
  res.json({ success: true });
});

// ==================== APP DATA SYNC ====================
// Salvar dados do AppContext (settings, stores, debts, saldoDia)
app.post('/api/sync/save', (req: Request, res: Response) => {
  const { settings, stores, debts, saldoDia, caixa, fechamento, lancamentos, lancamentosCompacto } = req.body;
  console.log('[DEBUG] Sync/Save recebido');
  console.log('[DEBUG] Lancamentos:', lancamentos ? 'SIM' : 'NÃO');
  console.log('[DEBUG] Settings:', settings ? 'SIM' : 'NÃO');
  if (settings) {
    dataStore.settings = settings;
    console.log('[DEBUG] fieldMappingCompacto1:', settings.fieldMappingCompacto1);
  }
  if (stores) dataStore.stores = stores;
  if (debts) dataStore.debts = debts;
  if (saldoDia !== undefined) dataStore.saldoDia = saldoDia;
  if (caixa) dataStore.caixa = caixa;
  if (fechamento) dataStore.fechamento = fechamento;
  
  // Aplicar mapeamento de campos aos lancamentos
  if (lancamentos) {
    // Verificar se deve usar mapeamento compacto ou padrao
    const storeId = Object.keys(lancamentos)[0];
    const mappingKey = storeId === 'loja1' ? 'fieldMappingCompacto1' : 'fieldMappingCompacto2';
    const hasCompactoMapping = dataStore.settings?.[mappingKey] && dataStore.settings[mappingKey].length > 0;
    
    let mappedLancamentos;
    if (hasCompactoMapping) {
      mappedLancamentos = applyFieldMappingCompacto(lancamentos, dataStore.settings);
    } else {
      mappedLancamentos = applyFieldMapping(lancamentos, dataStore.settings);
    }
    dataStore.lancamentos = mappedLancamentos;
  }
  
  saveDataToFile(dataStore);
  res.json({ success: true, timestamp: new Date().toISOString() });
});

// Função para aplicar mapeamento de campos aos lançamentos (FECHAMENTO padrão)
function applyFieldMapping(lancamentos: Record<string, any>, settings: Record<string, any>) {
  const mapped: Record<string, any> = {};
  
  for (const [storeId, storeData] of Object.entries(lancamentos)) {
    mapped[storeId] = {};
    
    for (const [date, entry] of Object.entries(storeData)) {
      const entryData = entry as Record<string, any>;
      const mappingKey = storeId === 'loja1' ? 'fieldMappingLan1' : 'fieldMappingLan2';
      const mapping = settings?.[mappingKey] || [];
      
      // Criar novo objeto com valores mapeados
      const mappedEntry: Record<string, any> = {
        date: entryData.date,
        values: {}
      };
      
      // Se não há mapeamento, usar valores originais
      if (!mapping || mapping.length === 0) {
        mappedEntry.values = entryData.values || {};
      } else {
        // Aplicar mapeamento
        const values = entryData.values || {};
        
        for (const map of mapping) {
          const { fechamento_field, lancamento_field } = map;
          if (fechamento_field && lancamento_field && values[fechamento_field] !== undefined) {
            mappedEntry.values[lancamento_field] = values[fechamento_field];
          }
        }
      }
      
      mapped[storeId][date] = mappedEntry;
    }
  }
  
  return mapped;
}

// Funcao para aplicar mapeamento de campos aos lancamentos (FECHAMENTO COMPACTO)
function applyFieldMappingCompacto(lancamentos: Record<string, any>, settings: Record<string, any>) {
  const mapped: Record<string, any> = {};
  
  for (const [storeId, storeData] of Object.entries(lancamentos)) {
    mapped[storeId] = {};
    
    for (const [date, entry] of Object.entries(storeData)) {
      const entryData = entry as Record<string, any>;
      const mappingKey = storeId === 'loja1' ? 'fieldMappingCompacto1' : 'fieldMappingCompacto2';
      const mapping = settings?.[mappingKey] || [];
      
      // Criar novo objeto com valores mapeados
      const mappedEntry: Record<string, any> = {
        date: entryData.date,
        values: {}
      };
      
      // Se nao ha mapeamento, usar valores originais
      if (!mapping || mapping.length === 0) {
        mappedEntry.values = entryData.values || {};
      } else {
        // Aplicar mapeamento
        const values = entryData.values || {};
        
        for (const map of mapping) {
          const { fechamento_field, lancamento_field } = map;
          if (fechamento_field && lancamento_field && values[fechamento_field] !== undefined) {
            mappedEntry.values[lancamento_field] = values[fechamento_field];
          }
        }
      }
      
      mapped[storeId][date] = mappedEntry;
    }
  }
  
  return mapped;
}

// Carregar dados do AppContext (sem userId, sincroniza tudo)
app.get('/api/sync/load', (_req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      settings: dataStore.settings || {},
      stores: dataStore.stores || {},
      debts: dataStore.debts || [],
      saldoDia: dataStore.saldoDia || 0,
      caixa: dataStore.caixa || {},
      fechamento: dataStore.fechamento || {},
      lancamentos: dataStore.lancamentos || {},
    },
    timestamp: new Date().toISOString()
  });
});

// Rota alternativa com userId (para compatibilidade)
app.get('/api/sync/load/:userId', (_req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      settings: dataStore.settings || {},
      stores: dataStore.stores || {},
      debts: dataStore.debts || [],
      saldoDia: dataStore.saldoDia || 0,
      caixa: dataStore.caixa || {},
      fechamento: dataStore.fechamento || {},
      lancamentos: dataStore.lancamentos || {},
    },
    timestamp: new Date().toISOString()
  });
});

// ==================== SYNC ENDPOINTS (Desktop App) ====================

// Health check para o programa desktop
app.get('/api/sync/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Adicionar anotação
app.post('/api/sync/annotation/add', (req: Request, res: Response) => {
  try {
    const { storeId, date, annotation } = req.body;
    console.log('[Server] Recebendo anotação:', { storeId, date, annotation });
    
    if (!dataStore.caixa[storeId]) {
      dataStore.caixa[storeId] = {};
    }
    if (!dataStore.caixa[storeId][date]) {
      dataStore.caixa[storeId][date] = { annotations: [] };
    }
    
    const newAnnotation = {
      id: Date.now(),
      ...annotation,
      createdAt: new Date().toISOString(),
    };
    
    dataStore.caixa[storeId][date].annotations.push(newAnnotation);
    saveDataToFile(dataStore);
    console.log('[Server] Anotação adicionada com sucesso:', newAnnotation);
    
    res.json({ success: true, data: newAnnotation });
  } catch (error) {
    console.error('[Server] Erro ao adicionar anotação:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// Atualizar anotação
app.post('/api/sync/annotation/update', (req: Request, res: Response) => {
  try {
    const { storeId, date, id, annotation } = req.body;
    
    if (dataStore.caixa[storeId] && dataStore.caixa[storeId][date]) {
      const annotations = dataStore.caixa[storeId][date].annotations || [];
      const index = annotations.findIndex((a: any) => a.id == id);
      
      if (index !== -1) {
        annotations[index] = { ...annotations[index], ...annotation, updatedAt: new Date().toISOString() };
        saveDataToFile(dataStore);
        res.json({ success: true, data: annotations[index] });
      } else {
        res.status(404).json({ success: false, error: 'Anotação não encontrada' });
      }
    } else {
      res.status(404).json({ success: false, error: 'Data ou loja não encontrada' });
    }
  } catch (error) {
    console.error('[Server] Erro ao atualizar anotação:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// Deletar anotação
app.post('/api/sync/annotation/delete', (req: Request, res: Response) => {
  try {
    const { storeId, date, id } = req.body;
    
    if (dataStore.caixa[storeId] && dataStore.caixa[storeId][date]) {
      const annotations = dataStore.caixa[storeId][date].annotations || [];
      const index = annotations.findIndex((a: any) => a.id == id);
      
      if (index !== -1) {
        annotations.splice(index, 1);
        saveDataToFile(dataStore);
        res.json({ success: true });
      } else {
        res.status(404).json({ success: false, error: 'Anotação não encontrada' });
      }
    } else {
      res.status(404).json({ success: false, error: 'Data ou loja não encontrada' });
    }
  } catch (error) {
    console.error('[Server] Erro ao deletar anotação:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// Salvar fechamento
app.post('/api/sync/closing/save', (req: Request, res: Response) => {
  try {
    const { storeId, date, closing } = req.body;
    console.log('[Server] Recebendo fechamento:', { storeId, date, closing });
    
    if (!dataStore.fechamento[storeId]) {
      dataStore.fechamento[storeId] = {};
    }
    
    dataStore.fechamento[storeId][date] = {
      ...closing,
      updatedAt: new Date().toISOString(),
    };
    
    saveDataToFile(dataStore);
    console.log('[Server] Fechamento salvo com sucesso');
    
    res.json({ success: true, data: dataStore.fechamento[storeId][date] });
  } catch (error) {
    console.error('[Server] Erro ao salvar fechamento:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// Obter anotações de uma data
app.get('/api/sync/annotations/:storeId/:date', (req: Request, res: Response) => {
  try {
    const { storeId, date } = req.params;
    
    if (dataStore.caixa[storeId] && dataStore.caixa[storeId][date]) {
      res.json({ success: true, data: dataStore.caixa[storeId][date].annotations || [] });
    } else {
      res.json({ success: true, data: [] });
    }
  } catch (error) {
    console.error('[Server] Erro ao obter anotações:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// Obter fechamento de uma data
app.get('/api/sync/closing/:storeId/:date', (req: Request, res: Response) => {
  try {
    const { storeId, date } = req.params;
    
    if (dataStore.fechamento[storeId] && dataStore.fechamento[storeId][date]) {
      res.json({ success: true, data: dataStore.fechamento[storeId][date] });
    } else {
      res.json({ success: true, data: {} });
    }
  } catch (error) {
    console.error('[Server] Erro ao obter fechamento:', error);
    res.status(500).json({ success: false, error: String(error) });
  }
});

// ==================== STATIC FILES ====================
// Serve static files from dist/client in production
if (process.env.NODE_ENV === 'production') {
  const distPath = path.join(__dirname, 'dist', 'client');
  app.use(express.static(distPath));
  app.get('*', (_req: Request, res: Response) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
} else {
  // Em desenvolvimento, redirecionar para Vite
  app.get('/', (req: Request, res: Response) => {
    const host = req.get('host') || 'localhost:5173';
    const ipAddress = host.split(':')[0];
    const viteUrl = `http://${ipAddress}:5173`;
    
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Financeiro DANADO</title>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <script type="module" src="${viteUrl}/@vite/client"><\/script>
          <script type="module" src="${viteUrl}/client/src/main.tsx"><\/script>
        </head>
        <body>
          <div id="root"><\/div>
        </body>
      </html>
    `);
  });
}

// ==================== START SERVER ====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Server] Running on http://0.0.0.0:${PORT}`);
  console.log(`[Server] API available at http://0.0.0.0:${PORT}/api`);
});
