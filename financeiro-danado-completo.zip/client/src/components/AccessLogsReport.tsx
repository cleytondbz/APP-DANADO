import { AccessLog } from '@/lib/types';

interface AccessLogsReportProps {
  logs: AccessLog[];
}

export function AccessLogsReport({ logs }: AccessLogsReportProps) {
  return (
    <div className="w-72 space-y-2" style={{width: '168px'}}>
      <h3 className="text-xs font-bold text-muted-foreground uppercase mb-2">Acessos do Dia</h3>
      <div className="space-y-1 max-h-96 overflow-y-auto border border-border rounded p-2 bg-muted/30">
        {logs.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center py-4">Sem acessos</p>
        ) : (
          logs.map((log) => {
            const hora = new Date(log.timestamp).toLocaleTimeString('pt-BR', { 
              hour: '2-digit', 
              minute: '2-digit' 
            });
            const acaoLabel = log.action === 'delete' ? 'Exclusão' : 'Edição';
            const acaoCor = log.action === 'delete' ? 'text-red-600' : 'text-blue-600';
            
            // Extrair tipo de pagamento dos detalhes
            const tipoMatch = log.details?.match(/: (\w+)$/);
            const tipo = tipoMatch ? tipoMatch[1] : 'desconhecido';
            const tipoLabel = tipo === 'dinheiro' ? 'Dinheiro' : tipo === 'pix' ? 'PIX' : tipo === 'cartao' ? 'Cartão' : tipo === 'boleto' ? 'Boleto' : tipo;
            
            return (
              <div 
                key={log.timestamp} 
                className="p-2 bg-background rounded border border-border/50 text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-foreground">{log.userName || 'Desconhecido'}</span>
                  <span className={`text-xs font-medium ${acaoCor}`}>{acaoLabel}</span>
                </div>
                <div className="text-muted-foreground text-xs">
                  <span className="font-medium">Tipo:</span> {tipoLabel}
                </div>
                <div className="text-muted-foreground/70 text-xs">{hora}</div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
