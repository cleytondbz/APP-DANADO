import { useApp } from '@/contexts/AppContext';
import { TrendingUp, ShoppingCart, Lock, CreditCard } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function SelectionScreen() {
  const { setScreen } = useApp();
  const [showSenhaVendas, setShowSenhaVendas] = useState(false);
  const [senhaVendasInput, setSenhaVendasInput] = useState('');
  const SENHA_VENDAS = '2512';

  const abrirVendas = () => {
    setShowSenhaVendas(true);
    setSenhaVendasInput('');
  };

  const confirmarSenhaVendas = () => {
    if (senhaVendasInput !== SENHA_VENDAS) {
      toast.error('Senha incorreta!');
      setSenhaVendasInput('');
      return;
    }
    setShowSenhaVendas(false);
    setSenhaVendasInput('');
    setScreen('storeSelection');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
        <h1 className="text-2xl font-bold text-foreground">app <span className="text-accent">Danado</span></h1>
        <p className="text-muted-foreground text-sm mt-2">Selecione a área desejada</p>
      </motion.div>

      <div className="flex flex-col gap-4 w-full max-w-sm">
        <div className="flex gap-4">
          <motion.button initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}
            onClick={abrirVendas}
            className="flex-1 bg-primary rounded-2xl p-6 flex flex-col items-center gap-3 hover:opacity-90 active:scale-95 transition-all card-glow"
          >
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
              <TrendingUp className="w-7 h-7 text-primary-foreground" />
            </div>
            <span className="text-primary-foreground font-bold text-lg">VENDAS</span>
            <span className="text-primary-foreground/70 text-xs">Gerenciar vendas</span>
          </motion.button>

          <motion.button initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}
            onClick={() => toast.info('Área de compras em desenvolvimento!')}
            className="flex-1 bg-muted rounded-2xl p-6 flex flex-col items-center gap-3 relative overflow-hidden opacity-60"
          >
            <div className="absolute top-2 right-2 bg-warning/20 text-warning text-[10px] font-bold px-2 py-0.5 rounded-full">EM BREVE</div>
            <div className="w-14 h-14 rounded-full bg-muted-foreground/10 flex items-center justify-center">
              <ShoppingCart className="w-7 h-7 text-muted-foreground" />
            </div>
            <span className="text-muted-foreground font-bold text-lg">COMPRAS</span>
            <span className="text-muted-foreground/50 text-xs">Em breve...</span>
            <Lock className="w-4 h-4 text-muted-foreground/40 absolute bottom-3 right-3" />
          </motion.button>
        </div>

        <motion.button initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          onClick={() => setScreen('caixaSelection')}
          className="w-full bg-accent rounded-2xl p-6 flex flex-col items-center gap-3 hover:opacity-90 active:scale-95 transition-all card-glow"
        >
          <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
            <CreditCard className="w-7 h-7 text-accent-foreground" />
          </div>
          <span className="text-accent-foreground font-bold text-lg">CAIXA</span>
          <span className="text-accent-foreground/70 text-xs">Fechamento de caixa</span>
        </motion.button>
      </div>

      {/* Modal de Senha para VENDAS */}
      {showSenhaVendas && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-background rounded-lg shadow-lg p-6 w-96 max-w-[90vw]"
          >
            <h2 className="text-lg font-bold text-foreground mb-4">Acesso à Área de Vendas</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Digite a senha para acessar a área de vendas.
            </p>
            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase mb-2 block">
                Senha
              </label>
              <Input
                type="password"
                value={senhaVendasInput}
                onChange={(e) => setSenhaVendasInput(e.target.value)}
                placeholder="Digite a senha"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    confirmarSenhaVendas();
                  }
                }}
                className="w-full"
                autoFocus
              />
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => {
                  setShowSenhaVendas(false);
                  setSenhaVendasInput('');
                }}
                variant="outline"
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={confirmarSenhaVendas}
                className="flex-1 bg-primary hover:bg-primary/90"
              >
                Confirmar
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
